package me.wcy.music.constants;

/**
 * Created by hzwangchenyan on 2018/1/26.
 */
public interface RxBusTags {
    String SCAN_MUSIC = "scan_music";
}
