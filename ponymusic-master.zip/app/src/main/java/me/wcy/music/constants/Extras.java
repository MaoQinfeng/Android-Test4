package me.wcy.music.constants;

/**
 * Extras
 * Created by hzwangchenyan on 2015/12/25.
 */
public interface Extras {
    String EXTRA_NOTIFICATION = "me.wcy.music.notification";
    String MUSIC_LIST_TYPE = "music_list_type";
    String TING_UID = "ting_uid";
    String MUSIC = "music";
}
