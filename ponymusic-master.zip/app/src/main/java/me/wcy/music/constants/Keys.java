package me.wcy.music.constants;

/**
 * Created by hzwangchenyan on 2017/9/28.
 */
public interface Keys {
    String VIEW_PAGER_INDEX = "view_pager_index";
    String LOCAL_MUSIC_POSITION = "local_music_position";
    String LOCAL_MUSIC_OFFSET = "local_music_offset";
    String PLAYLIST_POSITION = "playlist_position";
    String PLAYLIST_OFFSET = "playlist_offset";
}
