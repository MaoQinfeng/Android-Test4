package me.wcy.music.constants;

public interface RequestCode {
    int REQUEST_WRITE_SETTINGS = 0;
    int REQUEST_ALBUM = 1;
    int REQUEST_CORP = 2;
}
